# Jagdkurs
Das [Jagdkurs Wiki](https://eneller.github.io/Jagdkurs/) zum Jagdkurs 2021/22 Rudolf Ripper.
Die Gliederung folgt den Fächern der Prüfung und, soweit sinnvoll, dem Skript.

## Wie kann ich beitragen?
Das Jagdkurs Wiki lebt von **deinem** Beitrag. Um dies zu tun, kannst du mir Themenseiten gerne als Textdatei (so übersichtlich wie möglich) oder Markdown einreichen.
Markdown kannst du direkt hier auf [GitHub](https://github.com/join) schreiben. Für die nachfolgenden Schritte benötigst du einen Account hier auf GitHub, also [erstelle dir diesen](https://github.com/join) am besten gleich mit deiner Email-Adresse.
**[Für alle anderen Schritte, lies bitte hier weiter](./CONTRIBUTING.md)**

### Markdown (für Fortgeschrittene)
Über den Dialog *Add File > Create new File* kannst du eine Datei erstellen, der du einen Namen mit Endung *.md* gibst. Über die Schaltfläche *Preview* kannst du dann direkt sehen wie das Ergebnis nachher aussieht.

Eine umfassende, englische Zusammenfassung der Markdown Syntax ist [hier](https://github.com/tchapi/markdown-cheatsheet/blob/master/README.md) zu finden.

