## Dateien hochladen
Nachdem du deinen Beitrag geschrieben hast, musst du ihn nur noch hochladen. Solltest du einen Beitrag verändern wollen, mache bitte erkenntlich, welche Teile durch dich verändert wurden.

##### In das Jagdkurs-Wiki speichern

[Hier ist ein direkter Link](https://github.com/eneller/Jagdkurs/compare/contribute...main) um eine Pull Request zu erstellen. 
Klicke auf den Button *Create pull request*. Solltest du den Button nicht sehen oder anklicken können,stelle sicher dass bei base:contribute und compare:main ausgewählt ist. 
![Pull request erstellen](img/readme/PR_create.png)

Im Titel gibst du bitte an, ob es sich um 
* eine Änderung `edit:SeiteoderThema`, 
* einen Nachtrag auf einer bereits bestehenden Seite (ohne Änderung des Textes) `add:AbsatzaufSeite` oder * 
* einen komplett neuen Eintrag `new:Seite` handelt. 
![Pull request eingeben](img/readme/PR_submit.png)

Im Kommentar kannst du zum besseren Verständnis angeben, was genau deine Motivation war und was du getan hast. Unter dieser Textbox wählst du noch die Datei aus und sendest zuletzt du die Pull Request ab. Ich werde dann so schnell wie möglich deine Inhalte in die Seite einpflegen.

Vielen Dank!
