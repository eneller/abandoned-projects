// Open and close sidebar
function sidebar_toggle() {
 var x= document.getElementById("Sidebar")
    if (x.style.display === "block") {
        x.style.display = "none";
      } else {
        x.style.display = "block";
          }
}

//sort tables
/*
let table = document.getElementsByName("table")
table.querySelectorAll(`th`).forEach((th, position) => {
  th.addEventListener(`click`, evt => sortTable(position));
});


function compareValues(a, b) {
  // return -1/0/1 based on what you "know" a and b
  // are here. Numbers, text, some custom case-insensitive
  // and natural number ordering, etc. That's up to you.
  // A typical "do whatever JS would do" is:
  return (a<b) ? -1 : (a>b) ? 1 : 0;
}

function sortTable(colnum) {
  // get all the rows in this table:
  let rows = Array.from(table.querySelectorAll(`tr`));

  // but ignore the heading row:
  rows = rows.slice(1);

  // set up the queryselector for getting the indicated
  // column from a row, so we can compare using its value:
  let qs = `td:nth-child(${colnum})`;

  // and then just... sort the rows:
  rows.sort( (r1,r2) => {
    // get each row's relevant column
    let t1 = r1.querySelector(qs);
    let t2 = r2.querySelector(qs);

    // and then effect sorting by comparing their content:
    return compareValues(t1.textContent,t2.textContent);
  });

  // and then the magic part that makes the sorting appear on-page:
  rows.forEach(row => table.appendChild(row));
}
*/




//load navbar on DOM loaded, use echo `cat navbar.html` to get string without line breaks

$(document).ready(function() {
  $("#nav-placeholder").load("/Jagdkurs/components/navbar.html");
});
/*
navbar = '';
document.addEventListener("DOMContentLoaded", () =>{
  document.getElementById("nav-placeholder").innerHTML = '<nav id="SidebarContainer"> <div id="TopBar" class="accentColorBG mainColorFG"> <button class="hide-large sidebar-button" onclick="sidebar_toggle()">&#9776;</button> Jagdkurs-Wiki </div> <div id="Sidebar"> <details class="sidebar-item sidebar-item-level1"> <summary class="sidebar-item sidebar-item-level1">Vermischtes</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Jägersprache</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Naturschutz</a> </details> <details class="sidebar-item sidebar-item-level1"> <summary class="sidebar-item sidebar-item-level1">Wildtierökologie</summary> <details class="sidebar-item sidebar-item-level2"> <summary class="sidebar-item sidebar-item-level2">Schalenwild</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Damwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Elch</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Gamswild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Muffelwild</a> <a href="/Jagdkurs/html/wildtierbiologie/rehwild.html" class="sidebar-item sidebar-item-level3">Rehwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Rotwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Schwarzwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Sikawild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Steinwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wisent</a> </details> <details class="sidebar-item sidebar-item-level2"> <summary class="sidebar-item sidebar-item-level2">Haarwild</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Biber</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Bisam</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Feldhase</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Murmeltier</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Nutria</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Schneehase</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wildkaninchen</a> </details> <details class="sidebar-item sidebar-item-level2"> <summary class="sidebar-item sidebar-item-level2">Raubwild</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Baummarder</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Braunbär</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Dachs</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Fischotter</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Fuchs</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Großwiesel / Hermelin</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Iltis</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Luchs</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Marderhund</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Mauswiesel</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Steinmarder</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Waschbär</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wildkatze</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wolf</a> </details> <details class="sidebar-item sidebar-item-level2"> <summary class="sidebar-item sidebar-item-level2">Federwild</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Alpenschneehuhn</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Auerwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Birkwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Enten</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Fasan</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Haselwild</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Kormoran</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Möwe</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Rallen</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Rebhuhn</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Reiher</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Säger</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Taucher</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Waldschnepfe</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wildgans</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wildschwäne</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Wildtaube</a> </details> <details class="sidebar-item sidebar-item-level2"> <summary class="sidebar-item sidebar-item-level2">Greifvögel</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Eule</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Falke</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level3">Rabenvögel</a> </details> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Waldbau</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Landbau</a> </details> <details class="sidebar-item sidebar-item-level1"> <summary class="sidebar-item sidebar-item-level1">Jagdwaffen</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Fanggeräte</a> </details> <details class="sidebar-item sidebar-item-level1"> <summary class="sidebar-item sidebar-item-level1">Jagdhunde</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Jagdbetrieb</a> </details> <details class="sidebar-item sidebar-item-level1"> <summary class="sidebar-item sidebar-item-level1">Recht</summary> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Tierschutzgesetz</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Bundeswildschutzverordnung</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Landeswaldgesetz</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Unfallverhütungsvorschriften</a> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level2">Waffenrecht</a> </details> <a href="/Jagdkurs/html" class="sidebar-item sidebar-item-level1">Wildverwertung</a> <a href="/Jagdkurs/html/about.html" class="sidebar-item ">About</a> </div> </nav>';
});
*/

 
